const header = document.getElementById('header');


window.addEventListener("scroll",function(){
    if(this.scrollY>=50){
        header.classList.add('header-active')
    }else{
        header.classList.remove('header-active')
    }
})

